package com.table.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
public class SpringtablecheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtablecheckApplication.class, args);
	}

}
