/*
 * package com.table.java;
 * 
 * import static org.assertj.core.api.Assertions.assertThat;
 * 
 * import java.util.List;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.springframework.beans.factory.annotation.Autowired;
 * 
 * import com.table.java.model.Employee; import
 * com.table.java.repo.EmployeeRepository;
 * 
 * class EmployeeCrudTest {
 * 
 * @Autowired private EmployeeRepository Repo;
 * 
 * 
 * @Test public void EmployeeTest() { Employee employee=new
 * Employee((long)879791, "ram", "ram@gmail.com", "r&d", "7868098696");
 * 
 * assertThat(employee.getId()).isGreaterThan(0); }
 * 
 * @Test public void findEmployeeById() { Employee employee =
 * Repo.findById((long) 1).get();
 * 
 * assertThat(employee.getId()).isEqualTo(1); }
 * 
 * @Test public void getAll(){ List<Employee> employees = Repo.findAll();
 * 
 * assertThat(employees.size()).isGreaterThan(0); }
 * 
 * @Test public void testUpdate() { Employee employee=new Employee((long)879791,
 * "ram", "ram@gmail.com", "r&d", "7868098696");
 * 
 * employee.setDesignation("manager");
 * 
 * 
 * Employee employee2 = Repo.findById((long)1).get();
 * 
 * assertThat(employee2.getDesignation()).isEqualTo("manager"); }
 * 
 * @Test public void deleteTest() {
 * 
 * Employee employee = Repo.findById((long)2).get();
 * 
 * Repo.deleteById((long)1);
 * 
 * 
 * Employee employee2 = Repo.findById((long)1).get();
 * 
 * assertThat(employee2).isNull(); } }
 */